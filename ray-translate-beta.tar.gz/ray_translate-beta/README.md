# Translate app written in Rust ( Works only in linux )
__**ray_translate**__ - is something like translator in raycast.. but with worst design.

![image](https://github.com/user-attachments/assets/9128c58a-4e77-4946-9c0e-c76973ceb62b)



# Dependencies
`translate-shell`

Archlinux - `sudo pacman -S translate-shell`
